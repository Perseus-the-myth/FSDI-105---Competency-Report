console.log("User register");
//create constructor
class User{
    constructor(email,pass,first,last,age,address,phone,payment,color){
        this.email=email;
        this.password=pass;
        this.fname=first;
        this.lname=last;
        this.age=age;
        this.address=address;
        this.phone=phone;
        this.payment=payment;
        this.color=color;
    }
}




function isValid(user){
    // return false when the user is not valid
    // return true when the user is valid
    let valid = true;
    //We reset the original apperance all inputs
    //  by removing the error class (see style.css) 
    $('input').removeClass('error');
    if(user.fname.length == 0){
       //if we get here then the first name has not a valid value
       valid = false;
       //We add this error class (check css file) if the first name is not valid
       $("#firstName").addClass('error');
    }
    if(user.lname.length == 0){
        //is not a valid value
        $("#lastName").addClass('error');
        valid = false;
    }
    if(user.password.length == 0){
        //is not a valid value
        $("#userPassword").addClass('error');
        valid = false;
     }
     if(user.email.length == 0){
         //is not a valid value
         $("#userEmail").addClass('error');
         valid = false;
    }
    return valid;
}


function registerUser(){
    let email = $("#userEmail").val();//****check your id on the HTML */
    let password = $("#userPassword").val();
    let first = $("#firstName").val();
    let last = $("#lastName").val();
    let age = $("#userAge").val();
    let address = $("#userAddress").val();
    let phone = $("#userPhone").val();
    let payment = $("#userPayment").val();
    let color = $("#userColor").val();

    let user=new User(email,password,first,last,age,address,phone,payment,color);
    if(isValid(user)){
        //$('#usersTable').append(createRow(user));
    console.log(user);
    saveUser(user);//this fn is on the storeManager.js
}
clearInputs();
}
function clearInputs(){
    $("#firstName").val("");
    $("#lastName").val("");
    $("#userAge").val("");
    $("#userAddres").val("");
    $("#userPhone").val("");
    $("#userPayment").val("");
    $("#userColor").val("");
    $("#userEmail").val("");
    $("#userPassword").val("");
}
function init(){
    console.log("Init function");
    $("#btnSave").click(registerUsers);

}
window.onload=init();